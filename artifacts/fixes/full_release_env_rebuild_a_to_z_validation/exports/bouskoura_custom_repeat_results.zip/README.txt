Ouvrez le fichier .qgz dans QGIS pour utiliser le projet style.
Le projet s'ouvre directement sur l'etendue des resultats exportes.
Les dossiers contiennent les composants Shapefile bruts et les rasters de reference.
Si QGIS demande de reparer les chemins, conservez la structure des dossiers extraite du ZIP.
